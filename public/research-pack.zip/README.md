# Veritas Worldwide — Research Pack

Publisher: Veritas Worldwide only (entity attribution).
Generated: 2026-07-23T13:07:53.700Z

Contents are public machine-readable corpora used by the live site:
- evidence-taxonomy.json — scholarly + Volume I tier definitions
- profiles/corpus.json — Power Profiles index + integrity densify signals
- record-of-jesus-christ/corpus.json — ROC claim index
- israel-dossier/corpus.json — incidents, actors, money trail
- soft-floor.json files — live verification floors
- manifests — Israel templates/workbooks inventory
- llms.txt — AI/crawler index of public research surfaces

License / terms: see https://veritasworldwide.com/terms and https://veritasworldwide.com/privacy
Do not scrape beyond polite research use; production rate-limits corpus JSON.

No personal operator identity is included in this pack.
