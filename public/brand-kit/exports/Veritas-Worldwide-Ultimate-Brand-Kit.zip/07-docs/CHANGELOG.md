# Brand Kit Changelog — Veritas Worldwide Press

## 3.0.2 — 2026-07-23
- Add LinkedIn/Facebook post images to manifest downloads inventory

## 3.0.1
- LinkedIn post image (1200×627) + Facebook post image (1200×630)

## 3.0.0
- Mastodon banner, WhatsApp cover, presentation body slide
- Video end card + corner watermark
- bios.json (handles, bios, hashtags, contacts)
- Platform map: mastodon, whatsapp, video

## 2.9.8
- Brand guide regenerate + verify commands

## 2.9.7
- SOCIAL-ASSET-MATRIX lists Reddit banner + Reels safe-zone

## 2.9.6
- SOCIAL-LAUNCH checklist includes TikTok, Reddit, Reels safe-zone

## 2.9.5
- Reddit banner + Instagram Reels safe-zone template

## 2.9.4
- TikTok vertical cover template (1080×1920)

## 2.9.3
- Static media-kit.html links evidence tiers, Pinterest, social launch checklist

## 2.9.2
- Pinterest pin template + SOCIAL-LAUNCH.md checklist

## 2.9.1
- Dedicated Media Kit Open Graph card (05-og/og-media-kit)

## 2.9.0
- Bluesky banner, Discord invite card, citation card, correction notice HTML
- Platform map expanded (Bluesky + Discord)

## 2.8.0
- Threads post card + press contact vCard/MD

## 2.7.2
- tokens.json includes evidence color map (verified / circumstantial / disputed)

## 2.7.1
- Match evidence-tier card colors to product CSS tokens (#166534 / #92400E / #991B1B)
- Publish evidence tier CSS variables on tokens.css

## 2.7.0
- Align evidence-tier cards with product taxonomy: Verified, Circumstantial, Disputed
- Keep legacy Documented / Contested / Unverified assets for deep-link stability

## 2.6.0
- Evidence-tier social cards (Verified, Documented, Contested, Unverified)
- Presentation title slide (1920×1080) + podcast cover (1400×1400)
- X post card (1600×900), newsletter/Substack header, source attribution stamp
- Brand do/don't usage sheet
- PNG rasters for platform banners (X, LinkedIn, Facebook, YouTube, story)
- CHANGELOG.md (this file)

## 2.5.0
- LinkedIn article header, IG carousel slides 1–3, press release body HTML
- Media Kit UX: version badge, copy boilerplate, asset groups

## 2.4.0
- Quote card, YouTube thumbnail, brand voice doc, expanded verify live checks

## 2.3.0
- Story, highlights, business card, static media-kit.html, tokens.css

## 2.0.0 – 2.2.0
- Production vector system, ZIP + SHA-256, admin brand kit surface, AI refs
