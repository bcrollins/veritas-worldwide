# Social Asset Matrix — Veritas Worldwide Press

Use these paths when standing up or refreshing platform identities.
All paths are relative to `https://veritasworldwide.com`.

| Platform | Profile / logo | Banner / cover | Notes |
|----------|----------------|----------------|-------|
| **X (Twitter)** | `/brand-kit/04-social/social-profile.svg` or `social-profile-400.png` | `/brand-kit/04-social/social-banner-x.svg` (1500×500) | Handle @VeritasWorldwide |
| **Instagram** | same profile 320–400px PNG | Feed: square seal; Stories: `story-1080x1920.svg` | Handle @veritasworldwidepress |
| **Instagram Highlights** | `highlight-chapters.svg`, `highlight-sources.svg`, `highlight-record.svg` | — | 3 covers in 04-social |
| **LinkedIn Company** | `/brand-kit/01-logos/logo-mark-512.png` | `/brand-kit/04-social/social-banner-linkedin.svg` (1584×396) | Company: Veritas Worldwide Press |
| **Facebook Page** | profile PNG | `social-banner-facebook.svg` (820×312) | News/Media category |
| **YouTube** | app-icon / social-profile | `social-banner-youtube.svg` (2560×1440) | @VeritasWorldwide |
| **TikTok** | social-profile-400.png | N/A | @veritasworldwidepress |
| **Pinterest** | social-profile | story or OG for pins | veritasworldwide |
| **Open Graph / default share** | — | `/og-image.png` + `/brand-kit/05-og/` | Site-wide default |

## Bios (copy/paste)

- **Short:** Primary Sources. Public Record. Your Conclusions.
- **Medium:** A Documentary History of Power, Money, and the Institutions That Shaped the Modern World. 32 archive parts. 600+ primary sources. Full archive public.
- **Link:** https://veritasworldwide.com

## Hashtags

See `07-docs/HASHTAGS.md`.

## Full kit

Download: `/brand-kit/exports/Veritas-Worldwide-Ultimate-Brand-Kit.zip`  
Admin UI: `/admin/brand-kit`
